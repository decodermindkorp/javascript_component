
// let alphabet = "";

// const latters = ["a","b","c","d","e"];

// forEach(latters , function(char){

//     alphabet += char;

// });

// console.log(alphabet);

// ======================================================//


const addTwoItem = (a) => {

    return a+ 2;   

}
console.log(addTwoItem(1));

 function mapWith (array ,callback)
 {
        const newArray = [];

        forEach(array , (item) => {

            newArray.push(callback(item));               
        });

        return newArray;

 }

 console.log(mapWith([1,2,3] , addTwoItem));