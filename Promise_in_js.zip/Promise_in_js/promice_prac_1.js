// ======================================//
    //========promise intro =======//

const hasMetting = false;

const metting = new Promise((resolve,reject) => 
{
    if(!hasMetting)
    {
        const mettingDetail = {
            name: 'Technical metting',
            location : 'Google Meet',
            time : '10.00pm'
            };

      resolve(mettingDetail);
    }
    else
    {
        reject(new Error('metting already Schudle'))

    }


})


metting
      .then((res) =>   //human friendly loop here
      {
          console.log(JSON.stringify(res));
      })
      .catch ((err) => {
          console.log(err.message);

      })

      